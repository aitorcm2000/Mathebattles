/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package paneles;

import java.awt.Image;
import java.util.Objects;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import mathebattles.Criatura;
import static paneles.MFrame.cl;
import static paneles.MFrame.pl;

/**
 *
 * @author aitor
 */
public class Panel_ataques extends JLayeredPane{
    
    private final ImageIcon f_cambio = new ImageIcon("./recursos/Cambio.png");
    private final Image img_cambio = f_cambio.getImage().getScaledInstance(800, 500, Image.SCALE_SMOOTH);
    private final ImageIcon f_cambio_ajustado = new ImageIcon(img_cambio);
    
    private static JLabel at1;
    private static JLabel at2;
    private static JLabel at3;
    private static JLabel at4;
    private static JLabel l_cambio;
        
    private static Criatura al_ac;
    
    JButton b_at1 = new JButton("aaaaaaa");
    JButton b_at2 = new JButton("Cambio 2");
    JButton b_at3 = new JButton("Cambio 3");
    JButton b_at4 = new JButton("Atras");

    public Panel_ataques() {
        al_ac = Panel_Juego.getAl_ac();
        colocarElementos();
        colocarAtaques();
        actu_at();
    }
    
    
    
    private void colocarElementos (){
        b_at1.setBounds(50, 505, 300, 80);
        b_at2.setBounds(400, 505, 300, 80);
        b_at3.setBounds(50, 605, 300, 80);
        b_at4.setBounds(400, 605, 300, 80);
        
        b_at4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_atras_pulsado(evt);
            }
        });
        b_at1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_cambio_1_pulsado(evt);
            }
        });
        b_at2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_cambio_2_pulsado(evt);
            }
        });
        b_at3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_cambio_3_pulsado(evt);
            }
        });
  
    }
    
    /**
     * Al pulsar el boton se ejecuta el ataque introducido
     * @param evt 
     */
    private void b_atras_pulsado(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        cl.show(pl, "Batalla");
    }
    private void b_cambio_1_pulsado(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        Panel_Juego.setAl_ac(Panel_Juego.c1);
        Panel_Juego.setSpriteAl(1);

        cl.show(pl, "Batalla");
    } 
    private void b_cambio_2_pulsado(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        Panel_Juego.setAl_ac(Panel_Juego.c2);
        Panel_Juego.setSpriteAl(2);

        cl.show(pl, "Batalla");
    } 
    private void b_cambio_3_pulsado(java.awt.event.ActionEvent evt) {                                            
        // TODO add your handling code here:
        Panel_Juego.setAl_ac(Panel_Juego.c3);
        Panel_Juego.setSpriteAl(3);

        cl.show(pl, "Batalla");
    } 
    
    /**
     * Actualiza el contenido de los botones y los labels de ataques.toString() 
     * que muestran las estadisticas de los mismos.
     * 
     * Debe usarse cada vez que se abre el menu de ataques, para que esten acorde
     * a la criatura que esta en el campo.
     */
    public static void actu_at(){        
        at1 .setText(al_ac.getA1().toString());
        at2 .setText(al_ac.getA2().toString());
        at3 .setText(al_ac.getA3().toString());
        at4 .setText(al_ac.getA4().toString());
    }
    
    public void colocarAtaques(){
        at1 = new JLabel(al_ac.getA1().toString());
        at2 = new JLabel(al_ac.getA2().toString());
        at3 = new JLabel(al_ac.getA3().toString());
        at4 = new JLabel(al_ac.getA4().toString());
        l_cambio = new JLabel(f_cambio_ajustado);
        
        at1.setBounds(250, 50, 300, 300);
        at2.setBounds(250, 100, 300, 300);
        at3.setBounds(250, 150, 300, 300);
        at4.setBounds(250, 200, 300, 300);
        
        at1.setVisible(true);
        at2.setVisible(true);
        at3.setVisible(true);
        at4.setVisible(true);
        
        add(at1,10);
        add(at2,10);
        add(at3,10);
        add(at4,10);
        
        add(b_at1,10);
        add(b_at2,10);
        add(b_at3,10);
        add(b_at4,10);                
        add(l_cambio,100);
        l_cambio.setVisible(true);
    }

    
}
